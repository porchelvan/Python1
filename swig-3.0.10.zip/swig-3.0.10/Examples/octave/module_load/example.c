/* File : example.c */

#include "example.h"

int ivar = 47;

int ifunc() {
  return ivar;
}
