import shlex
from subprocess import Popen, PIPE
 
cmd = r"c:\users\datchanp\python271\strawberry\perl\bin\perl.exe v:\bin\postChatMsg.pl -c GSD_Credit_Market_L2 -m test.ignore -u _rskalert -p r1skAl3rt"
process = Popen(['c:\\users\\datchanp\\python271\\strawberry\\perl\\bin\\perl.exe ', 'v:\\bin\postChatMsg.pl', ' -c',' GSD_Credit_Market_L2',' -m',' test.ignore',' -u',' _rskalert',' -p',' r1skAl3rt' ], stdout=PIPE, shell=False)
process.communicate()    # execute it, the output goes to the stdout
exit_code = process.wait() 
#for line in process.stdout: process(line)
#exit_code = process.returncode
print exit_code
