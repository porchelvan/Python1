#!/sbcimp/run/pd/perl/5.8.5/bin/perl
# Routine to write a message line or file to a given IRC channel
#
 
use File::Basename;
my $basedir;
BEGIN { $basedir = File::Basename::dirname($0) };

use lib "$basedir\\..\\lib\\cpan\\5.8.8-2006.03\\lib";
use lib "$basedir\\..\\lib\\mindalign\\perl\\v1.0.719\\lib";
use com::parlano::irc;
use constant TIME_OUT => 20; # seconds
#use PD;
#use utils;
use Getopt::Std;
my %OPT;
my $INSTALL_BASE = "";
my $message;
my $nick_uniqueness;
my %properties;
my @msgs;

my $isFile=0;
#my $channel = "RISK_IT_AUTOMATIONS";
my $domain = "UBS.Bot";
#my $nick = "_ariskprd";
#my $nick = "_ariskgsd";

my $chathost = "botfw.ubs.net";
my $chatport = "6667";
my $authhost = "botfw.ubs.net";
my $authport = "2323";

getopts('c:m:f:u:p:',\%OPT);

if(  (!$OPT{c}) || ((!$OPT{m}) && (!$OPT{f})) || (!$OPT{u} || (!$OPT{p})) ) {
	print "\nUsage : \n $0 -c <channel> -m <message> [-f file] -u <botuser> -p <botpasswd>\n";	
	exit 10;
}

$channel = $OPT{c};
my $nick = $OPT{u};
my $pwd = $OPT{p};

if ($OPT{m}) {
	$message = $OPT{m};
	$isFile=0;
}
else {
	$isFile=1;
	if ( -r $OPT{f} ) {
		open(IN,"< $OPT{f}");
		@msgs=<IN>;
	}
	else {
		print "Could not read file $OPT{f}! Exiting\n";
		exit 11;
	}
}

close(STDOUT);
open(STDOUT,"/dev/null");

$HERE = File::Basename::dirname($0);

push(@INC, "$HERE");

my $original_nick = $nick;
my $next_num = 1;

# set IRC contact information
my $fullname = $channel;
my $userinfo;

my $token;

my $irc = com::parlano::irc->new();


##$log->debug("Authenticating...\n");


if ($domain eq "UBS.Bot") {
  my $authHash = $irc->doLogin($nick,$pwd,$authhost,$authport);
	die ("Can't authenticate") unless ($authHash->{success} == 1);
	$token = $authHash->{token};
}
elsif ($domain eq Interchange) {
  $chathost = "chat";
}
else {
	#$log->error("Unknown domain : $domain");
  die("Unknown domain $domain for channel $channel");
  
}

my $conn = $irc->newconn( Server    => $chathost,
                          Port      => $chatport,
                          auth      => $token,
                          Nick      => $nick,
                          Ircname   => $fullname,
                          Username  => $nick);

my $connected = 0;
my $channeljoined = 0;


# extract remaining flags

sub bot_reset {
  $nick_uniqueness = 1;
}



############## callback from irc connection
$conn->add_handler([376,422], \&on_connect);
sub on_connect {
  ##$log->debug("Inside the on_connect()\n");
  my ($conn, $event) = @_;
  #print VLOG "...connected\n" if ($verbose);
  ##$log->debug("connected...\n");
  $connected = 1;
}


############## callback from irc join
$conn->add_handler('join', \&on_join);

sub on_join {
  ##$log->debug("Inside the on_join()\n");
  my ($conn, $event) = @_;
  my ($thechannel) = $event->to();
  my $joinee = $event->nick();
  if ($joinee eq $conn->nick() && "#$channel" eq $thechannel) {
    ##$log->debug("...channel joined...\n");
    $channeljoined = 1;
  }
}

############## generating a new nick on nick collide
$conn->add_handler([433], \&on_nickcollide);

sub on_nickcollide {
  ##$log->debug("Inside the on_nickcollide()\n");
  my ($conn,$event) = @_;
  die ("unable to find a new nick after trying 9 variations") if (++$next_num == 10);
  my $nick = substr($original_nick,0,8) . ($next_num)   ;
  $conn->nick($nick);
  ##$log->debug("Nick collide, trying $nick\n");

}


############## On Invite
$conn->add_handler('invite', \&on_invite);

sub on_invite {
  ##$log->debug("Inside the on_invite()\n");
  my ($conn, $event) = @_;
  my $nick = $event->nick();
  my $userhost = $event->userhost();
  my ($channel) = $event->args();
  ##$log->debug("*** Invited to $channel by $nick $userhost\n");
  $conn->join($channel)
  if grep(/^\x23?$channel$/i, '#bots', @{ $channel });
}




############## On kick
$conn->add_handler('kick', \&on_kick);

sub on_kick {
  ##$log->debug("Inside the on_kick()\n");
  my ($conn, $event) = @_;
  my $user = $event->user(); # who did the kicking
  my @nicks = $event->to();  # who was kicked
  my ($channel) = $event->args();
  my $myNick = $conn->{_nick};

  #$log->debug("*** Kicked (@nicks) from $channel by $user \n");
  
  
  # check to see if i was kicked
  if (grep(/^$myNick\d*$/, @nicks)) {
    #$log->debug("*** I was kicked from $channel! \n");
    # sleep for 5s and then rejoin if this is 1 of my configured chans
    if (grep(/^\x23?$channel$/i, '#bots', @{ $channel })) {
      $rejoin{lc $channel} = 1;
    }
  }
}



############## On Invite Only
$conn->add_handler([473], \&on_invite_only);

sub on_invite_only {
  #$log->debug("Inside the on_invite_only()\n");
  my ($conn, $event) = @_;
  my ($myNick, $channel) = $event->args();

  #$log->debug("*** Can't join invite-only $channel \n");
}

############## On Nick taken : To remove as it is same as  nick collide
$conn->add_handler([433], \&on_nick_taken);

sub on_nick_taken {
  #$log->debug("Inside the on_nick_taken()\n");
  my ($conn, $event) = @_;
  my $newnick;

  $nick_uniqueness++;
  $newnick = substr($config->{NICK}, 0, 9-length($nick_uniqueness))
    . $nick_uniqueness;

  #print "Nick collision; trying $newnick\n" if ($config->{VERBOSE});
  #$log->debug("Nick collision; trying $newnick\n");
  $conn->nick($newnick);
}



############## On Disconnect
$conn->add_handler('disconnect', \&on_disconnect);

sub on_disconnect {
  #$log->debug("Inside the on_disconnect()\n");
  my ($conn, $event) = @_;
  my @args = $event->args();
  $conn = undef; # kill self so that the loop will realize and restart
}



my $timeout = time + TIME_OUT;
while (!$connected) {
  #$log->debug("checking connection ************()\n");
  $irc->do_one_loop();
  die("Timed-out connecting to chat server") if (time > $timeout);
}

my $result = $conn->join("#$channel");

while (!$channeljoined) {
  #$log->debug("checking channeljoined ************()\n");
  $irc->do_one_loop();
  if (time > $timeout ) {
    $conn->disconnect();
    die("Could not join the channel...exiting now...") ;
  }
}

if ( $isFile ) {
	my $msgCount=0;
	foreach(@msgs) {
		if($msgCount < 100) {
			chomp($_);
			$conn->privmsg("#$channel",cleanMsg($_) );
			select(undef, undef, undef, 0.25); 
		}
		else {
			my $exitMsg="**Due to MA constraints rest of the message will not be posted. GSD please check and update**";
			#$conn->privmsg("#$channel",cleanMsg($exitMsg) );
			last;
		}
		$msgCount++;
	}
}
else {
	$result = $conn->privmsg("#$channel",$message );
}

#$log->debug("Disconnecting...\n");
$conn->disconnect();

#$log->debug("Done...\n");

