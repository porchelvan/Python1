import time
import speech_recognition
import pyttsx
import os,sys
import subprocess
error='n'
Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
Settings_File=Base_Path + "\\v2\\config\\info.cfg"
name=''
mailid=''
spotlightreq=Base_Path +"\\v2\\config\\spotlightrequest.cfg"
spotlightresponse=Base_Path +"\\v2\\config\\spotlightresponse.txt"
brain=Base_Path +"\\v2\\config\\brain.cfg"


#################


	
###############		




def _sendrequest(request):
	global spotlightreq
	
	try:
		with open(spotlightreq, 'w') as outfile:
			outfile.write(request)
	except Exception as e:
		print e
def _deleteresponse():
	global spotlightresponse
	try:
		with open(spotlightresponse, 'w') as outfile:
			outfile.write("")
	except Exception as e:
		print e
def _getresponse():
	global spotlightresponse
	Split_Line=''
	try:
		Settings_File_Open= open(spotlightresponse,"r").read()
		Settings_File_Data = Settings_File_Open.split('\n')
		for i in range(len(Settings_File_Data)):
			Split_Line=Settings_File_Data[i].strip()
			if len(Split_Line)> 0:
				return Split_Line
		return Split_Line	
	except Exception as e:
		print e	
		return Split_Line	
def runSpeech():
	
	global name
	global mailid
	speech_engine = pyttsx.init('sapi5') # see http://pyttsx.readthedocs.org/en/latest/engine.html#pyttsx.init
	speech_engine.setProperty('rate', 150)
	
			


	def _getConfigName():
		global Settings_File
		global name
		global mailid
		
		try:
			Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
			Settings_File_Open= open(Settings_File,"r").read()
			Settings_File_Data = Settings_File_Open.split('\n')
			for i in range(len(Settings_File_Data)):
				if "name" in Settings_File_Data[i]:
					Split_Line=Settings_File_Data[i].split(":")
					name=Split_Line[1].strip()
				if "mailid" in Settings_File_Data[i]:
					Split_Line=Settings_File_Data[i].split("=")
					mailid=Split_Line[1].strip()
			print name
		except Exception as e:
			print e
			print "something wrong in config"
		
	def speak(text):
		speech_engine.say(text)
		speech_engine.runAndWait()
	
	recognizer = speech_recognition.Recognizer()
	_getConfigName()
	def listen():

		with speech_recognition.Microphone() as source:

			recognizer.adjust_for_ambient_noise(source)

			audio = recognizer.listen(source)

		try:
			return recognizer.recognize_google(audio)

		except speech_recognition.UnknownValueError:

			print("Could not understand audio")

		except speech_recognition.RequestError as e:

			print("Recog Error; {0}".format(e))



		return ""
	print "hi"
	loop=1
	_getresponse()
	
	while loop==1:
		print "hi"
		
		
		return_text=listen()
		
		print return_text
		if  "HELLO" in return_text.upper() or "SMARTY" in return_text.upper() or "CITY" in return_text.upper() or "YUBA" in return_text.upper()  or "UBS SIRI" in return_text.upper() or "SIRI" in return_text.upper()  or "UPS" in return_text.upper() :
	
			#speechtext="hi.  " + str(name) + "  What can i do for you"
			#speechtext="Hi. How can I help you today?"
			print speechtext
			#speak(speechtext)
			loop2=1	
			while loop2==1:
				
				#return_text=listen()
				
				if   "MARKET" in return_text.upper() or "RISK" in return_text.upper() or "INVESTMENT BANK" in return_text.upper(): 

					speak("Checking in Spotlight for the Market Risk data. ")
					_sendrequest(return_text)
					Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
					startscript=Base_Path + "\\brain.bat " 
								#os.system(startscript)
					subout=subprocess.call(startscript)
					brainresp=_getresponse()
					loop3=1
					while  loop3==1:
						time.sleep(2)
						brainresp=_getresponse()
						print "in loop"
						if len(brainresp.strip()) > 0:
							_deleteresponse()
							speak(brainresp)
							loop3=0
				
				elif "SERVICE NOW" in return_text.upper() or "SNOW" in return_text.upper() or "SERVICENOW" in return_text.upper() or "TICKET" in return_text.upper():
					speak("Checking in Service now for the ticket status.")
					_sendrequest(return_text)
					Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
					startscript=Base_Path + "\\brain.bat " 
								#os.system(startscript)
					subout=subprocess.call(startscript)
					brainresp=_getresponse()
					loop3=1
					while  loop3==1:
						time.sleep(2)
						brainresp=_getresponse()
						print "in loop"
						if len(brainresp.strip()) > 0:
							_deleteresponse()
							speak(brainresp)
							loop3=0
					print (return_text)
				elif   "MAIL" in return_text.upper() or "SEND" in return_text.upper() or "SCREENSHOT" in return_text.upper() or "SCREEN SHOT" in return_text.upper() : 
				
					speak("Sending Screenshot of the current view to Debananda Patro and Claus Norup. Please wait. ")
					_sendrequest(return_text)
					Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
					startscript=Base_Path + "\\brain.bat " 
								#os.system(startscript)
					subout=subprocess.call(startscript)
					brainresp=_getresponse()
					loop3=1
					while  loop3==1:
						time.sleep(2)
						brainresp=_getresponse()
						print "in loop"
						if len(brainresp.strip()) > 0:
							_deleteresponse()
							speak(brainresp)
							loop3=0
					print (return_text)
				
				elif   "ETA" in return_text.upper() or "CREDIT" in return_text.upper() or "DELIVERY" in return_text.upper() or "DELIVERABLES" in return_text.upper() or "KEY" in return_text.upper() : 
				
					speak("Checking in Splunk for Credit Key Deliverables ETA")
					_sendrequest(return_text)
					Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
					startscript=Base_Path + "\\brain.bat " 
								#os.system(startscript)
					subout=subprocess.call(startscript)
					brainresp=_getresponse()
					loop3=1
					while  loop3==1:
						time.sleep(2)
						brainresp=_getresponse()
						print "in loop"
						if len(brainresp.strip()) > 0:
							_deleteresponse()
							speak(brainresp)
							loop3=0
					print (return_text)
					
				elif "CLOSE" in return_text.upper() or "THANK YOU" in return_text.upper() or "THANKYOU" in return_text.upper() or "THANKS" in return_text.upper() : 
					speak("Ok. I am going to sleep. Call me for any assistance ")
					loop2=0	
				else:
					speak("Sorry. Please say it again")
					
		
		

		elif  "SHUTDOWN" in return_text.upper() or "EXIT" in return_text.upper()  or "SHUT DOWN" in return_text.upper()  or "QUIT" in return_text.upper():

			speak("Ok. I am Shutting Down. bye bye")

			loop=0	
		else:
			
			print (return_text)	
runSpeech()

