from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
import win32com.client
import pytz
import pyttsx,glob
from operator import itemgetter
import time
import subprocess,base64
#from datetime import *
import datetime
import sys,os,shutil
import logging
from logging.handlers import RotatingFileHandler
from _winreg import *
Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
spotlightconfig=Base_Path +"\\v2\\config\\spotlightconfig.txt"
spotlightresponse=Base_Path +"\\v2\\config\\spotlightresponse.txt"
sirirequest=Base_Path +"\\v2\\config\\spotlightrequest.cfg"
brain=Base_Path +"\\v2\\config\\brain.cfg"
brain=Base_Path +"\\v2\\config\\mail.cfg"
positionurl=''
screenshot=Base_Path+"\\v2\\Screenshot"
daily_digest=Base_Path+"\\daily-digest.htm"
error='n'
imgname=''
Python_path='C:\\Users\\datchanp\\Python271'
position="07:35::10:11::10:22::11:28"
IEDriver=Python_path+'\\Drivers\\IEDriverServer.exe'
flag=sys.argv[1]
Lock_File_Name=''
import win32com.client as win32
html_body=[]

def _spotlightres1():
	global spotlightresponse,daily_digest,html_body
	with open(daily_digest, 'r') as outfile:
		for line in outfile:
			html_body.append(line)
	outfile.close()
def sendmail(recipient,subject,body,attach):
	global html_body
	outlook = win32.Dispatch('outlook.application')
	mail = outlook.CreateItem(0)
	mail.To = recipient
	mail.Subject = subject
	mail.body = body
	mail.Attachments.Add(attach)
	mail.send
def _createLockFile(User_Name):
	global Lock_File_Name,Base_Path
	try:
		if len(glob.glob(Base_Path+"\\v2\\config\\.*.lck")) <= 0:
			hostname=os.environ['COMPUTERNAME']
			Lock_File_Name=Base_Path+"\\v2\\config\\."+hostname+"_"+User_Name+"_lock.lck"
			open(Lock_File_Name, 'w')
			print "Lock File is created " + str(Lock_File_Name)
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		print(exc_type, exc_obj, exc_tb.tb_lineno)
		print("ERROR --> Error reported in '_createLockFile' function")	
		
def _deleteLockFile():
	global Lock_File_Name,Base_Path,Settings_File
	try:
		lines = []
		print "file deleting"
		if len(glob.glob(Base_Path+"\\v2\\config\\.*.lck")) > 0:
			deletefile=glob.glob(Base_Path+"\\v2\\config\\.*.lck")
			os.remove(deletefile[0])
			print "file deleted"
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		print(exc_type, exc_obj, exc_tb.tb_lineno)
		print("ERROR --> Error reported in '_deleteLockFile' function")
		
def readmails():
	try:
		outlook = win32.Dispatch('outlook.application').GetNamespace("MAPI")
		timestamp = str('Timestamp: {:%Y-%m-%d/%H:%M:%S}'.format(datetime.datetime.now()))
		compdateyy = timestamp[13:15]
		compdatemm = timestamp[16:18]
		compdatedd = timestamp[19:21]
		compdate = compdatemm+ '/'+ compdatedd + '/'+compdateyy + " 00:00:00"
		#print compdate
		inbox = outlook.GetDefaultFolder(6)
		mymails=inbox.folders[2]
		messages=mymails.items
		message=messages.GetFirst()
		try:
			while message:
			#print str(datetime.datetime.strptime(str(compdate), "%m/%d/%y %H:%M:%S"))
			#print str(datetime.datetime.strptime(str(message.receivedtime),"%m/%d/%y %H:%M:%S"))
			#print str(message.receivedtime)
			
				if  True: #datetime.datetime.strptime(str(message.receivedtime),"%m/%d/%y %H:%M:%S") >=  datetime.datetime.strptime(compdate, "%m/%d/%y %H:%M:%S"):


					if message.unread==True:
						msg_from=message.Sender
						msg_imp=message.importance
						msg_sub=message.subject
						if int(msg_imp) >1:
							
							print "HIGH"+ "::"+str(msg_from) +"::" + str(msg_imp) + "::" + str(msg_sub)
						else:
							print "LOW"+"::"+str(msg_from) +"::" + str(msg_imp) + "::" + str(msg_sub)
						
					message = messages.GetNext()
				else:
					print "none"
					break
		except:
			print "except"
			pass
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		print(exc_type, exc_obj, exc_tb.tb_lineno)
		print str(e)
		pass
def readmeeting():
	try:
		outlook = win32.Dispatch('outlook.application').GetNamespace("MAPI")
		timestamp = str('Timestamp: {:%Y-%m-%d/%H:%M:%S}'.format(datetime.datetime.now()))
		compdateyy = timestamp[13:15]
		compdatemm = timestamp[16:18]
		compdatedd = timestamp[19:21]
		compdate = compdatemm+ '/'+ compdatedd + '/'+compdateyy + " 00:00:00"
		#print compdate
		inbox = outlook.GetDefaultFolder(9)
		mymails=inbox.folders[2]
		messages=mymails.items
		message=messages.GetFirst()
		try:
			while message:
			#print str(datetime.datetime.strptime(str(compdate), "%m/%d/%y %H:%M:%S"))
			#print str(datetime.datetime.strptime(str(message.receivedtime),"%m/%d/%y %H:%M:%S"))
				starttime=message.start
			
				if  datetime.datetime.strptime(str(starttime),"%m/%d/%y %H:%M:%S") >=  datetime.datetime.now():
					
					msg_from=message.Sender
					msg_imp=message.importance
					msg_sub=message.subject
					if int(msg_imp) >1:
							
						print "HIGH"+ "::"+str(msg_from) +"::" + str(msg_imp) + "::" + str(msg_sub)
					else:
						print "LOW"+"::"+str(msg_from) +"::" + str(msg_imp) + "::" + str(msg_sub)
						
					message = messages.GetNext()
				else:
					print "none"
					break
		except:
			print "except"
			pass
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		print(exc_type, exc_obj, exc_tb.tb_lineno)
		print str(e)
		pass	
def sendsms(recipient,subject,body):
	import win32com.client as win32
	outlook = win32.Dispatch('outlook.application')
	mail = outlook.CreateItem(0)
	mail.To = recipient
	mail.Subject = subject
	mail.body = body
	#mail.Attachments.Add(attach)
	mail.send
def _setIEZoomLevel():
	keyVal = r'Software\Microsoft\Internet Explorer\Zoom'
	try:
		key = OpenKey(HKEY_CURRENT_USER, keyVal, 0, KEY_ALL_ACCESS)
	except:
		key = CreateKey(HKEY_CURRENT_USER, keyVal)
	
	SetValueEx(key, "ZoomFactor",0, REG_DWORD,100000)
	CloseKey(key)
	

def _spotlightres(data):
	global spotlightresponse
	with open(spotlightresponse, 'w') as outfile:
			
					outfile.write(data)
	outfile.close()


	
def _getConfigName():
	global sirirequest
	global positionurl
	Split_Line=''
	
	try:
		Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
		Settings_File_Open= open(sirirequest,"r").read()
		Settings_File_Data = Settings_File_Open.split('\n')
		for i in range(len(Settings_File_Data)):
			if "::ack" not in Settings_File_Data[i]:
				Split_Line=Settings_File_Data[i]
				print Split_Line
				return Split_Line
		
		
	except Exception as e:
		print e
		
def _ackrequest(putack):
	global sirirequest
	global positionurl
	Split_Line=[]
	
	try:
		Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
		Settings_File_Open= open(sirirequest,"r").read()
		Settings_File_Data = Settings_File_Open.split('\n')
		for i in range(len(Settings_File_Data)):
			if putack in Settings_File_Data[i]:
				Split_Line.append(Settings_File_Data[i] + " ::ack")
			else:
				Split_Line.append(Settings_File_Data[i])
				
		with open(sirirequest, 'w') as outfile:
			for line in Split_Line:
				outfile.write(line+"\n")
		
	except Exception as e:
		print e
		
def _getrequest():
	global spotlightconfig
	global positionurl

	
	try:
		Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
		Settings_File_Open= open(spotlightconfig,"r").read()
		Settings_File_Data = Settings_File_Open.split('\n')
		for i in range(len(Settings_File_Data)):
			if "position" in Settings_File_Data[i]:
				Split_Line=Settings_File_Data[i].split(":::")
				positionurl=Split_Line[1].strip()
		print 	positionurl
	except Exception as e:
		print e
		
		#else:
		#	pass

	

def _stopHeadlessBrowser():
	
	os.system('taskkill /F /IM headless_ie_selenium.exe /T')
	os.system('taskkill /F /IM IEDriverServer.exe /T')
	
	
	
def _stopBrowser(browser_name):
	global Browser
	if int(Browser) == 1:
		os.system('taskkill /F /IM headless_ie_selenium.exe /T')
		os.system('taskkill /F /IM IEDriverServer.exe /T')
		
	elif int(Browser) == 2:
		if browser_name != 'null': 
			browser_name.quit()



def _searchElement(Tag_Name,Tag_Value,RLB_IE_Browser):
	global screenshot,error
	error='n'
	Retrie_Option=0
	try:
		while Retrie_Option < 1:
			try:
				if Tag_Name == 'ID':
					Element_Value=WebDriverWait(RLB_IE_Browser, 10).until(
					        EC.presence_of_element_located((By.ID , Tag_Value))
    					)
    				elif Tag_Name == 'CLASS':
					Element_Value=WebDriverWait(RLB_IE_Browser, 10).until(
					        EC.presence_of_element_located((By.CLASS_NAME , Tag_Value))
    					)
    				elif Tag_Name == 'XPATH':
					Element_Value=WebDriverWait(RLB_IE_Browser, 10).until(
					        EC.presence_of_element_located((By.XPATH , Tag_Value))
    					)
    				elif Tag_Name == 'LINK_TEXT':
					Element_Value=WebDriverWait(RLB_IE_Browser, 10).until(
					        EC.presence_of_element_located((By.LINK_TEXT, Tag_Value))
    					)
    				elif Tag_Name == 'FRAME':
					Element_Value=WebDriverWait(RLB_IE_Browser, 10).until(
						EC.frame_to_be_available_and_switch_to_it((By.ID, Tag_Value))
					)
					
    				return Element_Value
    			except TimeoutException:
    				print "Warning : unable to find the element id '%s'. Timeout exception occured. Retrying now." %(Tag_Value)
					
    				Retrie_Option=Retrie_Option+1
				imgname=screenshot + "browser_error.png"
    				RLB_IE_Browser.save_screenshot(imgname)
    				if Retrie_Option >=3: raise Exception()
    		
    	except Exception as e:
		error='y'
		
		
		_stopBrowser(RLB_IE_Browser)



def _positionurl():
			
	Retrie_Login_Count=0
	Retrie_Report_Count=0
	Retrie_Dispatch_Count=0
	global IEDriver
	global positionurl
	global screenshot
	global imgname
	#RLB_IE_Browser = webdriver.Ie(IEDriver)
	
	while Retrie_Login_Count < 3:
		try:
			print("Checking WebSSO Authentication")
			
			_setIEZoomLevel()
			RLB_IE_Browser = webdriver.Ie(IEDriver)
			RLB_IE_Browser.maximize_window()
			RLB_IE_Browser.get('https://spotlight.ubs.net/Pages/default.aspx?f_cob=2016-11-15&f_node=0&f_level=0&f_legalnode=-1')
			
			
			bodyText=RLB_IE_Browser.find_element_by_tag_name('body').text
			_searchElement("XPATH","//div[@id='positionexcesses']/span",RLB_IE_Browser)
			time.sleep(5)
			excess_position=_searchElement("XPATH","//div[@id='positionexcesses']/span",RLB_IE_Browser).text
			#res="Yes, we have " +excess_position + "  position excessess. Do you want to check for any Specific Asset?"
			#_spotlightres(res)
			
			imgname=screenshot + "\\spotlight_Excess.png"
    			RLB_IE_Browser.save_screenshot(imgname)
			
			res="I can see " +excess_position + " position excessess. Do you want to check for any Specific Asset?"
			_spotlightres(res)
			
			#RLB_IE_Browser.refresh()
			
			print imgname
			#print html_source
			#sendmail('porchelvan.datchanamoorthy@ubs.com',"test","test",imgname)
			#highest_exess=_searchElement("XAPTH","//div[@id='webpart-prioritised-risk-measures']/div/div[@id='wid-6-priority_0']",RLB_IE_Browser)
			
			
			Retrie_Login_Count=10
		    	
		except Exception as e:
			print e
			#RLB_IE_Browser.quit()
			#_stopHeadlessBrowser()
			
			Retrie_Login_Count +=1
			#RLB_IE_Browser.quit()
			if Retrie_Login_Count >= 3:
				_stopBrowser(RLB_IE_Browser)
				res="Sorry. Unable to process your Request. Please try again"
				_spotlightres(res)
def _snowurl():
			
	Retrie_Login_Count=0
	Retrie_Report_Count=0
	Retrie_Dispatch_Count=0
	global IEDriver
	global positionurl
	global screenshot
	global imgname
	inc_Number='INC1000009998'
	incstatus=''
	#RLB_IE_Browser = webdriver.Ie(IEDriver)
	
	while Retrie_Login_Count < 3:
		try:
			print("Opening Service now")
			
			_setIEZoomLevel()
			RLB_IE_Browser = webdriver.Ie(IEDriver)
			RLB_IE_Browser.maximize_window()
			#RLB_IE_Browser.get('https://snow.ubs.net/navpage.do')
			RLB_IE_Browser.get('https://gsnowtest.ubstest.net/incident.do?sys_id=0ff69faeb112320008959fa0cdc5d8de&sysparm_record_target=incident&sysparm_record_row=2&sysparm_record_rows=5&sysparm_record_list=active%3Dtrue%5Eassignment_group%3Djavascript%3AgetMyGroups%28%29%5Estate%3D2%5EORstate%3D5%5EORstate%3D701%5Eu_duplicate_incident%3Dfalse%5EORDERBYnumber')
			
			inc=_searchElement('ID','incident.number',RLB_IE_Browser).get_attribute('value')
			print inc
			if str(inc) == str(inc_Number):
				Incident_State=_searchElement('ID', 'incident.state',RLB_IE_Browser).get_attribute('value')
				if str(Incident_State) == "701":
					incstatus="Assigned"
				if str(Incident_State) == "601":
					incstatus="Resolved"	
				if str(Incident_State) == "2":
					incstatus="In Progress"	
				if str(Incident_State) == "3":
					incstatus="Closed"
				if str(Incident_State) == "400":
					incstatus="Cancelled"
				if str(Incident_State) == "5":
					incstatus="On Hold"
				if str(Incident_State) == "3":
					incstatus="Closed" 
				print  incstatus
				#inc_worknotes=	_searchElement('XPATH','//table[@id="activity_detail.4961983a8087e2003e3d77b0875f3d30"]/tbody/tr[2]/td/span/div',RLB_IE_Browser).text	
				#print inc_worknotes
			#res="Service now Ticket I N C 0 0 1 7 1 2 9 6 3 4  is " + incstatus+ " with the following comments!!! " + inc_worknotes
			res="Service now Ticket "+ inc_Number.replace("", "  ")[1: -1] +"  is " + incstatus
			_spotlightres(res)
			print res
			speech_engine = pyttsx.init('sapi5') # see http://pyttsx.readthedocs.org/en/latest/engine.html#pyttsx.init
			speech_engine.setProperty('rate', 150)
			speech_engine.say(res)
			speech_engine.runAndWait()
			imgname=screenshot + "\\snow_status.png"
    			RLB_IE_Browser.save_screenshot(imgname)
			
			
			#RLB_IE_Browser.refresh()
			
			
			#print html_source
			#sendmail('porchelvan.datchanamoorthy@ubs.com',"test","test",imgname)
			#highest_exess=_searchElement("XAPTH","//div[@id='webpart-prioritised-risk-measures']/div/div[@id='wid-6-priority_0']",RLB_IE_Browser)
			
			
			Retrie_Login_Count=10
		    	_stopHeadlessBrowser()	
			_deleteLockFile()
		except Exception as e:
			print e
			#RLB_IE_Browser.quit()
			#_stopHeadlessBrowser()
			
			Retrie_Login_Count +=1
			#RLB_IE_Browser.quit()
			if Retrie_Login_Count >= 3:
				_stopBrowser(RLB_IE_Browser)
				res="Sorry. Unable to process your Request. Please try again"
				_spotlightres(res)
def _bbsApproval():
			
	Retrie_Login_Count=0
	Retrie_Report_Count=0
	Retrie_Dispatch_Count=0
	global IEDriver
	global positionurl
	global screenshot
	global imgname
	inc_Number='INC1000009998'
	incstatus=''
	#RLB_IE_Browser = webdriver.Ie(IEDriver)
	
	while Retrie_Login_Count < 3:
		try:
			print("Opening BBS PAge")
			
			_setIEZoomLevel()
			RLB_IE_Browser = webdriver.Ie(IEDriver)
			RLB_IE_Browser.maximize_window()
			#RLB_IE_Browser.get('https://snow.ubs.net/navpage.do')
			#RLB_IE_Browser.get('https://bw.bbs.ubs.ch/itauth/bbs/')
			#_searchElement('ID','002',RLB_IE_Browser).click()
			RLB_IE_Browser.get('https://bw.bbs.ubs.ch/itauth/bbs/controller/AppReqServlet;jsessionid=0000lY4x9JR3QTw49P6Ea3Obs7n:-1?Type=Query')
			
			_searchElement('XPATH','//html/body/div[2]/form/table[3]/tbody/tr',RLB_IE_Browser)
			noReq=len(RLB_IE_Browser.find_elements_by_xpath('//html/body/div[2]/form/table[3]/tbody/tr'))
			print noReq
			
				#inc_worknotes=	_searchElement('XPATH','//table[@id="activity_detail.4961983a8087e2003e3d77b0875f3d30"]/tbody/tr[2]/td/span/div',RLB_IE_Browser).text	
				#print inc_worknotes
			#res="Service now Ticket I N C 0 0 1 7 1 2 9 6 3 4  is " + incstatus+ " with the following comments!!! " + inc_worknotes
			res="You have " + str(int(noReq) -2) + " to approval"
			_spotlightres(res)
			print res
			speech_engine = pyttsx.init('sapi5') # see http://pyttsx.readthedocs.org/en/latest/engine.html#pyttsx.init
			speech_engine.setProperty('rate', 150)
			speech_engine.say(res)
			speech_engine.runAndWait()
			imgname=screenshot + "\\snow_status.png"
    			RLB_IE_Browser.save_screenshot(imgname)
			
			
			#RLB_IE_Browser.refresh()
			
			
			#print html_source
			#sendmail('porchelvan.datchanamoorthy@ubs.com',"test","test",imgname)
			#highest_exess=_searchElement("XAPTH","//div[@id='webpart-prioritised-risk-measures']/div/div[@id='wid-6-priority_0']",RLB_IE_Browser)
			
			
			Retrie_Login_Count=10
		    	#_stopHeadlessBrowser()	
			_deleteLockFile()
		except Exception as e:
			print e
			#RLB_IE_Browser.quit()
			#_stopHeadlessBrowser()
			
			Retrie_Login_Count =3
			#RLB_IE_Browser.quit()
			if Retrie_Login_Count >= 3:
				_stopBrowser(RLB_IE_Browser)
				res="Sorry. Unable to process your Request. Please try again"
				_spotlightres(res)
				
def _calendar():
			
	Retrie_Login_Count=0
	Retrie_Report_Count=0
	Retrie_Dispatch_Count=0
	global IEDriver
	global positionurl
	global screenshot
	global imgname
	inc_Number='INC1000009998'
	incstatus=''
	#RLB_IE_Browser = webdriver.Ie(IEDriver)
	
	while Retrie_Login_Count < 3:
		try:
			print("Opening calendar PAge")
			
			_setIEZoomLevel()
			RLB_IE_Browser = webdriver.Ie(IEDriver)
			RLB_IE_Browser.maximize_window()
			#RLB_IE_Browser.get('https://snow.ubs.net/navpage.do')
			#RLB_IE_Browser.get('https://bw.bbs.ubs.ch/itauth/bbs/')
			#_searchElement('ID','002',RLB_IE_Browser).click()
			RLB_IE_Browser.get('https://tableau.ubs.net/t/prd/views/MandMMyCalendar/MMMyCalendar2?:embed=y&:showShareOptions=true&:display_count=no&:showVizHome=no')
			
			time.sleep(2)
			
				#inc_worknotes=	_searchElement('XPATH','//table[@id="activity_detail.4961983a8087e2003e3d77b0875f3d30"]/tbody/tr[2]/td/span/div',RLB_IE_Browser).text	
				#print inc_worknotes
			#res="Service now Ticket I N C 0 0 1 7 1 2 9 6 3 4  is " + incstatus+ " with the following comments!!! " + inc_worknotes
			res="Calendar Planner is opened for your."
			_spotlightres(res)
			print res
			speech_engine = pyttsx.init('sapi5') # see http://pyttsx.readthedocs.org/en/latest/engine.html#pyttsx.init
			speech_engine.setProperty('rate', 150)
			speech_engine.say(res)
			speech_engine.runAndWait()
			imgname=screenshot + "\\snow_status.png"
    			RLB_IE_Browser.save_screenshot(imgname)
			
			
			#RLB_IE_Browser.refresh()
			
			
			#print html_source
			#sendmail('porchelvan.datchanamoorthy@ubs.com',"test","test",imgname)
			#highest_exess=_searchElement("XAPTH","//div[@id='webpart-prioritised-risk-measures']/div/div[@id='wid-6-priority_0']",RLB_IE_Browser)
			
			
			Retrie_Login_Count=10
		    	#_stopHeadlessBrowser()	
			_deleteLockFile()
		except Exception as e:
			print e
			#RLB_IE_Browser.quit()
			#_stopHeadlessBrowser()
			
			Retrie_Login_Count +=1
			#RLB_IE_Browser.quit()
			if Retrie_Login_Count >= 3:
				_stopBrowser(RLB_IE_Browser)
				res="Sorry. Unable to process your Request. Please try again"
				_spotlightres(res)
def _splunkurl():
			
	Retrie_Login_Count=0
	Retrie_Report_Count=0
	Retrie_Dispatch_Count=0
	global IEDriver
	global positionurl
	global screenshot
	global imgname
	global position
	#RLB_IE_Browser = webdriver.Ie(IEDriver)
	
	while Retrie_Login_Count < 1:
		try:
			print("Opening Splunk")
			
			_setIEZoomLevel()
			RLB_IE_Browser = webdriver.Ie(IEDriver)
			RLB_IE_Browser.maximize_window()
			RLB_IE_Browser.get('http://nzur460215uap:8000/en-US/app/search/autosys_job_status#en-US/app/search/autosys_job_status?form.time_token.earliest=-1d%40d&form.time_token.latest=%40d&earliest=0&latest=')
			try:
				time.sleep(2)
				RLB_IE_Browser.find_element_by_id('username')
		    		Passwd_Element=_searchElement('ID','password',RLB_IE_Browser)
		    		Username_Element=_searchElement('ID','username',RLB_IE_Browser)
		    		Username_Element.clear()
		    		Username_Element.send_keys("admin")
		    		Passwd_Element.send_keys('Splunk_X123')
		    		Login_Element=_searchElement('XPATH',"//form[@class='loginForm']/fieldset/input[1]",RLB_IE_Browser).send_keys(Keys.RETURN)
				RLB_IE_Browser.get('http://nzur460215uap:8000/en-US/app/search/autosys_job_status#en-US/app/search/autosys_job_status?form.time_token.earliest=-1d%40d&form.time_token.latest=%40d&earliest=0&latest=')
		    	except NoSuchElementException:
				print "Exception caught"
				pass
			
			print "1"
			
			time.sleep(10)
			
			report1=_searchElement("XPATH","//div[@id='element1']/div[1]/h3",RLB_IE_Browser).text
			
			
			print report1
			report1_time=position.strip().split("::")[0]
			
			report2=_searchElement("XPATH","//div[@id='element2']/div[1]/h3",RLB_IE_Browser).text
			report2_time=position.strip().split("::")[1]
			report3=_searchElement("XPATH","//div[@id='element3']/div[1]/h3",RLB_IE_Browser).text
			report3_time=position.strip().split("::")[2]
			report4=_searchElement("XPATH","//div[@id='element4']/div[1]/h3",RLB_IE_Browser).text
			report4_time=position.strip().split("::")[3]
			#/div/div[2]/div/svg/g/g/g/g/g/g/text
			
			
			print report1_time
			print report4_time
			print report3_time
			print report2_time
			
			
			imgname=screenshot + "\\splunk.png"
    			RLB_IE_Browser.save_screenshot(imgname)
			
			res=" Credit Key Deliverables ETA details sent you as SMS. "
			_spotlightres(res)
			sms_text="ETA for Credit Key Deliverables below\n " +report1+ " -- " + report1_time + " GMT \n" + report2+ " -- " + report2_time + " GMT \n " +report3+ " -- " + report3_time + " GMT \n " +report4+ " -- " + report4_time + " GMT \n"
			#RLB_IE_Browser.refresh()
			sendsms('006581110143@smsgw.ch',"Credit key sms", sms_text)
			print res
			#print html_source
			#sendmail('porchelvan.datchanamoorthy@ubs.com',"test","test",imgname)
			#highest_exess=_searchElement("XAPTH","//div[@id='webpart-prioritised-risk-measures']/div/div[@id='wid-6-priority_0']",RLB_IE_Browser)
			
			
			Retrie_Login_Count=10
		    	
		except Exception as e:
			print e
			#RLB_IE_Browser.quit()
			#_stopHeadlessBrowser()
			
			Retrie_Login_Count +=1
			#RLB_IE_Browser.quit()
			if Retrie_Login_Count >= 3:
				_stopBrowser(RLB_IE_Browser)
				res="Sorry. Unable to process your Request. Please try again"
				_spotlightres(res)
				
loop=True
#readmails()


print "flag : " + str(flag)
if loop==1:
				
		#a=_getConfigName()			
		if int(flag) ==1 :
			#if "MARKET" in a.upper() or "RISK" in a.upper() or "INVESTMENT BANK"  in a.upper() or "INVESTMENTBANK" in a.upper() or "VIEW" in a.upper():
			#	_ackrequest(a)
			#	_positionurl()
			#if "MAIL" in a.upper() or "SEND" in a.upper() or  "SCREENSHOT" in a.upper() or "SCREEN SHOT" in a.upper() :
			#	print "mail sending"
			#	try:
			#		_ackrequest(a)
			#		imgname=screenshot + "\\spotlight_Excess.png"
			#		sendmail('porchelvan.datchanamoorthy@ubs.com',"Market Risk View for Investment Bank", "Please find the attached the Market Risk View of Investment Bank \n\nThank You",imgname)	
			#		res="Market Risk View for Investment Bank sent to the specificed people"
			#		_spotlightres(res)
			#	except Exception as e:
			#		print e
			#		res="Sorry. Unable to process your Request. Please try again"
			#		_spotlightres(res)
		
			#_ackrequest(a)
			_snowurl()
			#time.sleep(5)	
			#if "CREDIT" in a.upper() or "ETA" in a.upper() or "KEY"  in a.upper() or "DELIVERY" in a.upper() :
			#	_ackrequest(a)
			#	_splunkurl()
		elif int(flag)==2:
			_spotlightres1()
			sendmail('debananda.patro@ubs.com',"DAILY DIGEST REPORT","Hi Deb, \nPlease find the attached Daily Report from UBS SMART.\n\nThank You.",daily_digest)
			_deleteLockFile()
		elif int(flag) ==3 :
			_bbsApproval()
		elif int(flag)==4:
			_calendar()
		else:
			print "no file"
			loop=0
	
		
		