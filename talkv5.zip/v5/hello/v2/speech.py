import speech_recognition
import pyttsximport os,sys
import timefrom selenium.webdriver.common.keys import Keysfrom selenium import webdriverfrom selenium.webdriver.support.ui import WebDriverWaitfrom selenium.webdriver.support.ui import Selectfrom selenium.webdriver.support import expected_conditions as ECfrom selenium.common.exceptions import TimeoutExceptionfrom selenium.common.exceptions import NoSuchElementExceptionfrom selenium.webdriver.common.by import Byimport win32com.clientfrom _winreg import *import webbrowserBrowser=2error='n'Python_path='C:\\Users\\datchanp\\Python271'Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))IEDriver_Hide=Python_path+'\\Drivers\\headless_ie_selenium.exe'IEDriver=Python_path+'\\Drivers\\IEDriverServer.exe'screenshot=Base_Path+ "\\Screenshot\\Dispatcher\\"
speech_engine = pyttsx.init('sapi5') # see http://pyttsx.readthedocs.org/en/latest/engine.html#pyttsx.init
speech_engine.setProperty('rate', 150)def _stopBrowser(browser_name):	global Browser	if int(Browser) == 1:		os.system('taskkill /F /IM headless_ie_selenium.exe /T')		os.system('taskkill /F /IM IEDriverServer.exe /T')			elif int(Browser) == 2:		if browser_name != 'null': 			browser_name.quit()						
def _setIEZoomLevel():	keyVal = r'Software\Microsoft\Internet Explorer\Zoom'	try:		key = OpenKey(HKEY_CURRENT_USER, keyVal, 0, KEY_ALL_ACCESS)	except:		key = CreateKey(HKEY_CURRENT_USER, keyVal)		SetValueEx(key, "ZoomFactor",0, REG_DWORD,100000)	CloseKey(key)
def speak(text):
	speech_engine.say(text)
	speech_engine.runAndWait()def _searchElement(Tag_Name,Tag_Value,RLB_IE_Browser):	global error	Python_path='C:\\Users\\datchanp\\Python271'	Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))	IEDriver_Hide=Python_path+'\\Drivers\\headless_ie_selenium.exe'	IEDriver=Python_path+'\\Drivers\\IEDriverServer.exe'	screenshot=Base_Path+ "\\Screenshot\\Dispatcher\\"	error='n'	Retrie_Option=0	try:		while Retrie_Option < 3:			try:				if Tag_Name == 'ID':					Element_Value=WebDriverWait(RLB_IE_Browser, 30).until(					        EC.presence_of_element_located((By.ID , Tag_Value))    					)    				elif Tag_Name == 'CLASS':					Element_Value=WebDriverWait(RLB_IE_Browser, 30).until(					        EC.presence_of_element_located((By.CLASS_NAME , Tag_Value))    					)    				elif Tag_Name == 'XPATH':					Element_Value=WebDriverWait(RLB_IE_Browser, 30).until(					        EC.presence_of_element_located((By.XPATH , Tag_Value))    					)    				elif Tag_Name == 'LINK_TEXT':					Element_Value=WebDriverWait(RLB_IE_Browser, 30).until(					        EC.presence_of_element_located((By.LINK_TEXT, Tag_Value))    					)    				elif Tag_Name == 'FRAME':					Element_Value=WebDriverWait(RLB_IE_Browser, 60).until(						EC.frame_to_be_available_and_switch_to_it((By.ID, Tag_Value))					)					    				return Element_Value    			except TimeoutException:    				#print "Warning : unable to find the element id '%s'. Timeout exception occured. Retrying now." %(Tag_Value)				    				Retrie_Option=Retrie_Option+1				imgname=screenshot + "browser_error.png"    				RLB_IE_Browser.save_screenshot(imgname)    				if Retrie_Option >=3: raise Exception()    		    	except Exception as e:		error='y'		_stopBrowser(RLB_IE_Browser)		
def Open_Snow():		global error	Python_path='C:\\Users\\datchanp\\Python271'	Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))	IEDriver_Hide=Python_path+'\\Drivers\\headless_ie_selenium.exe'	IEDriver=Python_path+'\\Drivers\\IEDriverServer.exe'	screenshot=Base_Path+ "\\Screenshot\\Dispatcher\\"	Retrie_Login_Count=0	Retrie_Report_Count=0	Retrie_Dispatch_Count=0	
	while Retrie_Login_Count < 3:		_setIEZoomLevel()		RLB_IE_Browser = webdriver.Ie(IEDriver)		RLB_IE_Browser.maximize_window()				try:											RLB_IE_Browser.get('https://snow.ubs.net/navpage.do')			try:							RLB_IE_Browser.find_element_by_id('inputpassword')		    		Passwd_Element=_searchElement('ID','inputpassword',RLB_IE_Browser)		    		Auth_Element=_searchElement('ID','selectedauth',RLB_IE_Browser)		    		for option in Auth_Element.find_elements_by_tag_name('option'):		    			if option.text == 'IB-WebSSO':		    			    	#option.send_keys(Keys.RETURN)		    			    	option.click()		    			    	break		    		Username_Element=_searchElement('ID','inputusername',RLB_IE_Browser)		    		Username_Element.clear()		    		Username_Element.send_keys(User_Name)		    		Passwd_Element.send_keys(Password)		    		Login_Element=_searchElement('CLASS','cuiButton',RLB_IE_Browser).send_keys(Keys.RETURN)		    	except NoSuchElementException:				print "Exception caught"				pass		    				    				    	Snow_Authentication_Check=_searchElement('ID','gsft_logout',RLB_IE_Browser)		    	imgname=screenshot + "Tktcnt_open.png"    			RLB_IE_Browser.save_screenshot(imgname)		    	#RLB_IE_Browser=RLB_IE_Browser		    	Retrie_Login_Count = 10			print 	Retrie_Login_Count			error='n'			return 0		except Exception as e:			error='y'
			print "except"			#RLB_IE_Browser.quit()			#_stopHeadlessBrowser()			Retrie_Login_Count +=1			if Retrie_Login_Count >= 3: 				_stopBrowser(RLB_IE_Browser)				return 1
								

recognizer = speech_recognition.Recognizer()

def listen():
	with speech_recognition.Microphone() as source:
		recognizer.adjust_for_ambient_noise(source)
		audio = recognizer.listen(source)

	try:		return recognizer.recognize_google(audio)
	except speech_recognition.UnknownValueError:
		print("Could not understand audio")
	except speech_recognition.RequestError as e:
		print("Recog Error; {0}".format(e))

	return ""
loop=1while loop==1:	
	speak("Say something!")	return_text=listen()
	if  "hello" in return_text or "ubs" in return_text or "talk" in return_text:
		print (return_text) 		
		speak("What can i do for you")				
		return_text=listen()		
		if   "spotlight" in return_text or "spot" in return_text or "light" in return_text: 
			speak("Let me open SpotLight Application. Please wait. ")
			print (return_text)
		else:
			print (return_text)		if "service now" in return_text or "snow" in return_text or "servicenow" in return_text:			speak("Let me open Service Now Application for you. Please wait. ")						webbrowser.open('https://snow.ubs.net/navpage.do')			time.sleep(5)			if error == 'n':					speak("Service Now Application is ready for you to access.")			else:							speak("I am sorry. Unable to open Service Now Application.")		else:			print (return_text)				
	else:
		print (return_text)
	if  "thank you" in return_text or "close" in return_text:
		speak("Ok. I am going to sleep. bye bye")
		loop=0

		