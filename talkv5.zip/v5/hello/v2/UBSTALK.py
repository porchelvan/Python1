import Tkinter as tk
from Tkinter import Canvas, PhotoImage
from Tkinter import *
import time
import speech_recognition
import pyttsx
import os,sys
import subprocess
error='n'
Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
Settings_File=Base_Path + "\\config\\info.cfg"
name=''
mailid=''
x = 0

def animate(self):
    global x
    if x == 10:
        x = 0
    else:
        self.pic["format"] = "gif -index " + str(x)
        self.label1["image"] = self.pic
        x += 1

    

    self.after(50, lambda: animate(self))

def center(toplevel):
    toplevel.wm_title("UBS Talk")
    w = 200 
    h = 200
    x = toplevel.winfo_screenwidth() - (w + 20)
    y = toplevel.winfo_screenheight() - (h + 100)
    toplevel.geometry("%dx%d+%d+%d" % (w,h,x, y))
    toplevel.wm_attributes("-topmost",1)
    toplevel.iconbitmap(default='UBSTALK.ico')
    toplevel.resizable(0,0)
    #toplevel.geometry('300x200+120+80')	
	


class run(tk.Tk):

    def __init__(self, *args, **kwargs):
	tk.Tk.__init__(self, *args, **kwargs)
	
        
        self.pic = PhotoImage(file="preview.gif", format = "gif -index 4")

        self.label1 = tk.Label(width=200, height=300)
        self.label1.pack(expand="no", fill="both")
	
	center(self)
        animate(self)
		
	#self.after(300, lambda: runSpeech(self))
	Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
	startscript=Base_Path + "\\speech.bat "
	subprocess.call(startscript)

run().mainloop()