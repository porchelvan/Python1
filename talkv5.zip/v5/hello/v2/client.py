from Tkinter import *
import time
import speech_recognition
import pyttsx
import os,sys
error='n'
Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
Settings_File=Base_Path + "\\config\\info.cfg"
name=''
mailid=''
root=Tk()
root.title("UBS Talk")
x = root.winfo_screenwidth() - 220
y = root.winfo_screenheight() - 300
w=200
h=200
print root.winfo_screenwidth()
root.wm_geometry("%dx%d%+d%+d" % (w, h, x, y))
root.transient()
root.resizable(0,0)
root.wm_attributes("-topmost",1)
def minimize(root):
	root.wm_state('iconic')
def maximize(root):	
	root.wm_state('normal')
	

		
		#else:
		#	pass

def runSpeech():
	import webbrowser
	global name
	global mailid
	speech_engine = pyttsx.init('sapi5') # see http://pyttsx.readthedocs.org/en/latest/engine.html#pyttsx.init
	speech_engine.setProperty('rate', 150)
	
	def _getConfigName():
		global Settings_File
		global name
		global mailid
		
		try:
			Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
			Settings_File_Open= open(Settings_File,"r").read()
			Settings_File_Data = Settings_File_Open.split('\n')
			for i in range(len(Settings_File_Data)):
				if "name" in Settings_File_Data[i]:
					Split_Line=Settings_File_Data[i].split(":")
					name=Split_Line[1].strip()
				if "mailid" in Settings_File_Data[i]:
					Split_Line=Settings_File_Data[i].split("=")
					mailid=Split_Line[1].strip()
			print name
		except Exception as e:
			print e
			print "something wrong in config"
		
	def speak(text):
		speech_engine.say(text)
		speech_engine.runAndWait()
	
	recognizer = speech_recognition.Recognizer()
	_getConfigName()
	def listen():

		with speech_recognition.Microphone() as source:

			recognizer.adjust_for_ambient_noise(source)

			audio = recognizer.listen(source)

		try:
			return recognizer.recognize_google(audio)

		except speech_recognition.UnknownValueError:

			print("Could not understand audio")

		except speech_recognition.RequestError as e:

			print("Recog Error; {0}".format(e))



		return ""
	print "hi"
	loop=1
	while loop==1:
	
		speak("Say something!")
		speak(name)
		return_text=listen()

		if  "hello" in return_text or "ubs" in return_text or "talk" in return_text or "Talk" in return_text:

			print (return_text) 
			
			speechtext="hello  " + str(name) + "  What can i do for you"
			print speechtext
			speak(speechtext)
		
		
			return_text=listen()
		
			if   "spotlight" in return_text or "spot" in return_text or "light" in return_text: 

				speak("Let me open SpotLight Application. Please wait. ")

				print (return_text)

			else:

				print (return_text)
			if "service now" in return_text or "snow" in return_text or "servicenow" in return_text:
				speak("Let me open Service Now Application for you. Please wait. ")
			
				webbrowser.open('https://snow.ubs.net/navpage.do')
				time.sleep(5)
				if error == 'n':	
					speak("Service Now Application is ready for you to access.")
				else:
			
					speak("I am sorry. Unable to open Service Now Application.")
			else:

				print (return_text)		
		
		else:

			print (return_text)

		if  "thank you" in return_text or "close" in return_text:

			speak("Ok. I am going to sleep. bye bye")

			loop=0	
			
root.after(300,runSpeech)
	

root.mainloop()

