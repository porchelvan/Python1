from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
import win32com.client
import pytz
from operator import itemgetter
import time
import subprocess,base64
#from datetime import *
import datetime
import sys,os,shutil
import logging
from logging.handlers import RotatingFileHandler
from _winreg import *
Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
spotlightconfig=Base_Path +"\\spotlightconfig.txt"
spotlightresponse=Base_Path +"\\spotlightresponse.txt"
positionurl=''
screenshot=Base_Path
error='n'
Python_path='C:\\Users\\shankasi\\Python271'
IEDriver=Python_path+'\\Drivers\\IEDriverServer.exe'
def sendmail(recipient,subject,body,attach):
	import win32com.client as win32
	outlook = win32.Dispatch('outlook.application')
	mail = outlook.CreateItem(0)
	mail.To = recipient
	mail.Subject = subject
	mail.body = body
	mail.Attachments.Add(attach)
	mail.send
def _setIEZoomLevel():
	keyVal = r'Software\Microsoft\Internet Explorer\Zoom'
	try:
		key = OpenKey(HKEY_CURRENT_USER, keyVal, 0, KEY_ALL_ACCESS)
	except:
		key = CreateKey(HKEY_CURRENT_USER, keyVal)
	
	SetValueEx(key, "ZoomFactor",0, REG_DWORD,100000)
	CloseKey(key)
	

def _spotlightres(data):
	global spotlightresponse
	with open(spotlightresponse, 'w') as outfile:
			
					outfile.write(data)
	outfile.close()
	
def _getConfigName():
	global spotlightconfig
	global positionurl

	
	try:
		Base_Path=os.path.abspath(os.path.dirname(sys.argv[0]))
		Settings_File_Open= open(spotlightconfig,"r").read()
		Settings_File_Data = Settings_File_Open.split('\n')
		for i in range(len(Settings_File_Data)):
			if "position" in Settings_File_Data[i]:
				Split_Line=Settings_File_Data[i].split(":::")
				positionurl=Split_Line[1].strip()
		print 	positionurl
	except Exception as e:
		print e
		
		#else:
		#	pass

	

def _stopHeadlessBrowser():
	
	os.system('taskkill /F /IM headless_ie_selenium.exe /T')
	os.system('taskkill /F /IM IEDriverServer.exe /T')
	
	
	
def _stopBrowser(browser_name):
	global Browser
	if int(Browser) == 1:
		os.system('taskkill /F /IM headless_ie_selenium.exe /T')
		os.system('taskkill /F /IM IEDriverServer.exe /T')
		
	elif int(Browser) == 2:
		if browser_name != 'null': 
			browser_name.quit()



def _searchElement(Tag_Name,Tag_Value,RLB_IE_Browser):
	global screenshot,error
	error='n'
	Retrie_Option=0
	try:
		while Retrie_Option < 3:
			try:
				if Tag_Name == 'ID':
					Element_Value=WebDriverWait(RLB_IE_Browser, 30).until(
					        EC.presence_of_element_located((By.ID , Tag_Value))
    					)
    				elif Tag_Name == 'CLASS':
					Element_Value=WebDriverWait(RLB_IE_Browser, 30).until(
					        EC.presence_of_element_located((By.CLASS_NAME , Tag_Value))
    					)
    				elif Tag_Name == 'XPATH':
					Element_Value=WebDriverWait(RLB_IE_Browser, 30).until(
					        EC.presence_of_element_located((By.XPATH , Tag_Value))
    					)
    				elif Tag_Name == 'LINK_TEXT':
					Element_Value=WebDriverWait(RLB_IE_Browser, 30).until(
					        EC.presence_of_element_located((By.LINK_TEXT, Tag_Value))
    					)
    				elif Tag_Name == 'FRAME':
					Element_Value=WebDriverWait(RLB_IE_Browser, 60).until(
						EC.frame_to_be_available_and_switch_to_it((By.ID, Tag_Value))
					)
					
    				return Element_Value
    			except TimeoutException:
    				print "Warning : unable to find the element id '%s'. Timeout exception occured. Retrying now." %(Tag_Value)
					
    				Retrie_Option=Retrie_Option+1
				imgname=screenshot + "browser_error.png"
    				RLB_IE_Browser.save_screenshot(imgname)
    				if Retrie_Option >=3: raise Exception()
    		
    	except Exception as e:
		error='y'
		
		
		_stopBrowser(RLB_IE_Browser)


def _positionurl1():
			
	Retrie_Login_Count=0
	Retrie_Report_Count=0
	Retrie_Dispatch_Count=0
	global IEDriver
	global positionurl
	
	#RLB_IE_Browser = webdriver.Ie(IEDriver)
	
	while Retrie_Login_Count < 1:
		try:
			print("Checking WebSSO Authentication")
			
			_setIEZoomLevel()
			RLB_IE_Browser = webdriver.Ie(IEDriver)
			RLB_IE_Browser.maximize_window()
			RLB_IE_Browser.get("https://spotlight.ubs.net/_vti_bin/Spotlight/Data2.svc/GetEvents?f_cob=2016-11-16&f_node=0&f_level=0&f_legalnode=-1")
			html_source = RLB_IE_Browser.page_source
			print html_source
			with open('tyext.txt', 'w') as outfile:
			
					outfile.write(html_source)
			Retrie_Login_Count=10
		except Exception as e:
			print e

def _positionurl():
			
	Retrie_Login_Count=0
	Retrie_Report_Count=0
	Retrie_Dispatch_Count=0
	global IEDriver
	global positionurl
	global screenshot
	#RLB_IE_Browser = webdriver.Ie(IEDriver)
	
	while Retrie_Login_Count < 1:
		try:
			print("Checking WebSSO Authentication")
			
			_setIEZoomLevel()
			RLB_IE_Browser = webdriver.Ie(IEDriver)
			RLB_IE_Browser.maximize_window()
			RLB_IE_Browser.get(positionurl)
			
			
			bodyText=RLB_IE_Browser.find_element_by_tag_name('body').text
			_searchElement("XPATH","//div[@id='positionexcesses']/span",RLB_IE_Browser)
			time.sleep(5)
			excess_position=_searchElement("XPATH","//div[@id='positionexcesses']/span",RLB_IE_Browser).text
			res="Yes, we have " +excess_position + "  position excessess. Do you want to check for any Specific Asset?"
			_spotlightres(res)
			print res
			
			RLB_IE_Browser.get('https://spotlight.ubs.net/Pages/Radar.aspx?f_cob=2016-11-16&f_node=0&f_level=0&f_legalnode=-1')
			bodyText=RLB_IE_Browser.find_element_by_tag_name('body').text
			time.sleep(5)
			_searchElement("ID","posExcessTog",RLB_IE_Browser).click()
			time.sleep(5)
			#RLB_IE_Browser.refresh()
			imgname=screenshot + "\\spotlight_Excess.png"
    			RLB_IE_Browser.save_screenshot(imgname)
			print imgname
			#print html_source
			sendmail('porchelvan.datchanamoorthy@ubs.com',"test","test",imgname)
			#highest_exess=_searchElement("XAPTH","//div[@id='webpart-prioritised-risk-measures']/div/div[@id='wid-6-priority_0']",RLB_IE_Browser)
			
			
			Retrie_Login_Count=10
		    	
		except Exception as e:
			print e
			#RLB_IE_Browser.quit()
			#_stopHeadlessBrowser()
			
			Retrie_Login_Count +=1
			#RLB_IE_Browser.quit()
			_stopBrowser(RLB_IE_Browser)
			return 2

_getConfigName()			
#_positionurl()			
			
_positionurl()