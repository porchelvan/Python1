from flask import Flask, render_template, request
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
from chatterbot.trainers import ListTrainer
import  jsonify


app = Flask(__name__)

conversation = [
    "Hello",
    "Hi there!",
    "How are you doing?",
    "I'm doing great.",
    "That is good to hear",
    "Thank you.",
    "You're welcome."
]

english_bot = ChatBot("Chatterbot", storage_adapter="chatterbot.storage.SQLStorageAdapter")

#english_bot.set_trainer(ChatterBotCorpusTrainer)
#english_bot.train("chatterbot.corpus.english")
trainer = ListTrainer(english_bot)

trainer.train(conversation)

#@app.route("/")
#def home():
 #   return render_template("index4.html")
	
	

#@app.route("/get")
#def get_bot_response():
 #   userText = request.args.get('msg')
 #   return str(english_bot.get_response(userText))

@app.route("/") 
def hello():
	
	return render_template('chat.html')

@app.route("/ask", methods=['POST','GET'])
def ask():
	message = str(request.form['chatmessage'])
	bot_response = str(english_bot.get_response(message))
		# print bot_response
	return jsonify({'status':'OK','answer':bot_response})



if __name__ == "__main__":
    app.run()
